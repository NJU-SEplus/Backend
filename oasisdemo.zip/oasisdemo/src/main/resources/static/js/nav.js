$(function(){
	
	//click btn and add content
	$('#help-a').popover();
	
})