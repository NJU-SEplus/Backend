package com.example.oasisdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OasisdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
